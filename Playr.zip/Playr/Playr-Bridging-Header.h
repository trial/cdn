//
//  Playr-Bridging-Header.h
//  Playr
//
//  Created by jimmy on 7/18/22.
//

#ifndef Playr_Bridging_Header_h
#define Playr_Bridging_Header_h
#import <SJVideoPlayer/SJVideoPlayer.h>
#import "SJAVMediaPlaybackController.h"
#import "UIViewController+RotationControl.h"
#import <SJBaseVideoPlayer/SJPlaybackRecordSaveHandler.h>
#import "SJRotationManager_4.h"

#endif /* Playr_Bridging_Header_h */
