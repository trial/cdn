
#import "UIViewController+RotationControl.h"
#import "SJVideoPlayer.h"
#import <SJBaseVideoPlayer/SJPlaybackRecordSaveHandler.h>

@implementation UIViewController (RotationConfiguration)
- (BOOL)shouldAutorotate {
    return NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
@end


@implementation UITabBarController (RotationConfiguration)
- (UIViewController *)sj_topViewController {
    if ( self.selectedIndex == NSNotFound )
        return self.viewControllers.firstObject;
    return self.selectedViewController;
}

- (BOOL)shouldAutorotate {
    return [[self sj_topViewController] shouldAutorotate];
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return [[self sj_topViewController] supportedInterfaceOrientations];
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return [[self sj_topViewController] preferredInterfaceOrientationForPresentation];
}
@end

@implementation UINavigationController (RotationConfiguration)
- (BOOL)shouldAutorotate {
    return self.topViewController.shouldAutorotate;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return self.topViewController.supportedInterfaceOrientations;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return self.topViewController.preferredInterfaceOrientationForPresentation;
}

- (nullable UIViewController *)childViewControllerForStatusBarStyle {
    return self.topViewController;
}

- (nullable UIViewController *)childViewControllerForStatusBarHidden {
    return self.topViewController;
}
@end



@interface SJPlaybackRecord (SJTestExtended)
@property (nonatomic, copy, nullable) NSString *url;
@end

@implementation SJPlaybackRecord (SJTestExtended)
- (void)setUrl:(nullable NSString *)url {
    objc_setAssociatedObject(self, @selector(url), url, OBJC_ASSOCIATION_COPY_NONATOMIC);
}
- (nullable NSString *)url {
    return objc_getAssociatedObject(self, _cmd);
}
@end
