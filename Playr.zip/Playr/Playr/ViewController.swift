//
//  ViewController.swift
//  Playr
//
//  Created by jimmy on 7/18/22.
//

import SnapKit
import UIKit

class ViewController: UIViewController {
    var player = SJVideoPlayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        view.addSubview(player.view)
        player.view.snp.makeConstraints { make in
            make.top.equalTo(self.view.safeAreaLayoutGuide.snp.top)
            make.left.equalTo(view).offset(0)
            make.right.equalTo(view).offset(0)
            make.height.equalTo(UIScreen.main.bounds.width * 9 / 16)
        }

        player.playbackController = SJAVMediaPlaybackController()

        player.defaultEdgeControlLayer.topAdapter.removeItem(forTag: SJEdgeControlLayerTopItem_Back)
        player.defaultEdgeControlLayer.topAdapter.reload()
        player.defaultLoadFailedControlLayer.topAdapter.removeItem(forTag: SJEdgeControlLayerTopItem_Back)
        player.defaultLoadFailedControlLayer.topAdapter.reload()
        player.needHiddenStatusBar()
        player.defaultEdgeControlLayer.showsMoreItem = false
        player.isPausedInBackground = false
        player.resumePlaybackWhenAppDidEnterForeground = true
        player.defaultEdgeControlLayer.isHiddenBottomProgressIndicator = true
        player.defaultEdgeControlLayer.loadingView.showsNetworkSpeed = true
        player.gestureController.supportedGestureTypes = SJPlayerGestureTypeMask.all
        player.defaultEdgeControlLayer.bottomContainerView.cleanColors()
        player.defaultEdgeControlLayer.topContainerView.cleanColors()
        player.defaultEdgeControlLayer.leftAdapter.removeItem(forTag: SJEdgeControlLayerLeftItem_Lock)
        player.defaultEdgeControlLayer.leftAdapter.reload()

        guard let url = URL(string: "https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index.m3u8") else {
            return
        }
        player.urlAsset = SJVideoPlayerURLAsset(url: url)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        player.vc_viewDidAppear()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player.stop()
        player.vc_viewWillDisappear()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        player.vc_viewDidDisappear()
    }
}
